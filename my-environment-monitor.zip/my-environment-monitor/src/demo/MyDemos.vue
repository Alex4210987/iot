<!-- <template>
    <div>
        <p>{{ message }}</p>
        <button @click="updateMessage">Update Message</button>
    </div>
</template>

<script>
import { ref } from 'vue';

export default {

    setup() {
        // 使用 ref 来声明响应式数据
        const message = ref('Hello World!');

        // 定义一个方法来更新数据
        const updateMessage = () => {
            message.value = 'Updated Hello World!';
        };

        // 将数据和方法暴露给模板
        return {message,updateMessage}
    }
};
</script> -->
<template>
    <div>
      <p>{{ message }}</p>
      <button @click="updateMessage">Update Message</button>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        message: 'Hello World!'
      };
    },
    methods: {
      updateMessage() {
        this.message = 'Updated Hello World!';
      }
    }
  };
  </script>
  