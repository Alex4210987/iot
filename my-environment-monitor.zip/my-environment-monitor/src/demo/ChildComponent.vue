<template>
    <button @click="emitEvent">Click me!</button>
  </template>
  
  <script>
  export default {
    methods: {
      emitEvent() {
        this.$emit('child-event', 'Data from child component');
      }
    }
  };
  </script>
  