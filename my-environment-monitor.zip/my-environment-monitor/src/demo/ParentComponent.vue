<template>
    <div>
      <ChildComponent @child-event="handleChildEvent" />
      <p>Received from child: {{ eventData }}</p>
    </div>
  </template>
  
  <script>
  import ChildComponent from './ChildComponent.vue';
  
  export default {
    components: {
      ChildComponent
    },
    data() {
      return {
        eventData: ''
      };
    },
    methods: {
      handleChildEvent(data) {
        this.eventData = data;
      }
    }
  };
  </script>
  