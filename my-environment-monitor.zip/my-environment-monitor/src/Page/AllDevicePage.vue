<template>
<InputField/>
</template>
<script>
import InputField from "@/components/InputFieldComponents.vue";
export default {
  components: {
    InputField,
  },
};
</script>