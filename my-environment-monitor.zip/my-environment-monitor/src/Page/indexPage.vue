<template>
  <div class="index">

    <Environment :nowData="nowData" />
    <SoilMoistureChart :historyData="historyData" :nowData="nowData" />
    <TemperatureChart :historyData="historyData" :nowData="nowData" />
  </div>
</template>

<script>
import axios from "axios";
import Environment from '../components/Environment.vue';

export default {
  name: "IndexPage",
  components: {
    Environment, // 在组件中注册 Environment
  },
  data() {
    return {
      nowData: {
        timestamp: 0,
        temperature: 0,
        humidity: 0,
        soilHumidity: 0,
        precipitation: 0,
      },
      historyData: [],
    };
  },
  mounted() {
    this.getHistoryData();
    this.setupWebSocket();
  },
  methods: {
    async getHistoryData() {
      try {
        const response = await axios.get(
          `http://your-api-endpoint/data/history`
        );
        this.historyData = response.data.data;
        this.nowData = this.historyData.length > 0 ? this.historyData[0] : {};
      } catch (error) {
        console.error("Error fetching history data:", error);
      }
    },
    setupWebSocket() {
      const ws = new WebSocket(`ws://your-ws-endpoint`);
      ws.onmessage = (event) => {
        this.nowData = JSON.parse(event.data);
      };
    },
  },
};
</script>

<style scoped>
.index {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
  height: 20vh; /* 设置高度占满整个视口 */
}
</style>
