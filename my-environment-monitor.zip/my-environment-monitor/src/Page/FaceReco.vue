<template>
    <div class="face-recognition">
      <h2>人脸识别</h2>
      <button @click="showDialog = true" class="add-face-button">加入人脸库</button>
      <div v-if="showDialog" class="dialog-overlay" @click.self="closeDialog">
        <div class="dialog">
          <h3>加入人脸库</h3>
          <input type="file" @change="onFileChange" class="file-input" />
          <button @click="uploadFace" class="upload-button">提交图片</button>
          <button @click="closeDialog" class="close-button">关闭</button>
        </div>
      </div>
      <div class="records-section">
        <h3>当前园区人员状况</h3>
        <table>
          <thead>
            <tr>
              <th>姓名</th>
              <th>状态</th>
              <th>时间</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="record in records" :key="record.time">
              <td>{{ record.name }}</td>
              <td>{{ record.status }}</td>
              <td>{{ record.time }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        showDialog: false,
        file: null,
        records: []
      };
    },
    methods: {
      onFileChange(event) {
        this.file = event.target.files[0];
      },
      async uploadFace() {
      const formData = new FormData();
      formData.append('file', this.file);

      try {
        await axios.post('http://localhost:3070/face/add', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        alert('图片上传成功！');
      } catch (error) {
        console.error('上传失败:', error);
      }
    },
    async fetchRecords() {
      try {
        const response = await axios.get('http://localhost:3070/face/records');
        this.records = response.data;
      } catch (error) {
        console.error('获取记录失败:', error);
      }
    }
  },
  mounted() {
    this.fetchRecords();
    setInterval(this.fetchRecords, 10000); // 每10秒获取一次记录
  }
};
  </script>
  
  <style scoped>
  .face-recognition {
    padding: 20px;
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .face-recognition h2 {
    margin-bottom: 20px;
    color: #333;
  }
  
  .add-face-button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  .add-face-button:hover {
    background-color: #45a049;
  }
  
  .dialog-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .dialog {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    width: 300px;
    text-align: center;
  }
  
  .file-input {
    display: block;
    margin: 10px auto;
  }
  
  .upload-button, .close-button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin: 10px 5px;
  }
  
  .upload-button:hover, .close-button:hover {
    background-color: #45a049;
  }
  
  .records-section {
    margin-top: 20px;
  }
  
  .records-section h3 {
    margin-bottom: 10px;
  }
  
  .records-section table {
    width: 100%;
    border-collapse: collapse;
  }
  
  .records-section th, .records-section td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
  }
  
  .records-section th {
    background-color: #f2f2f2;
  }
  
  .records-section tr:nth-child(even) {
    background-color: #f9f9f9;
  }
  </style>
  