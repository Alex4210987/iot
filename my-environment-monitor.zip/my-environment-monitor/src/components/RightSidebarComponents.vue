<script>
import UserList from "@/components/UserListComponents.vue";
import UserIcon from "@/components/icon/UserIcon.vue";
import DeviceList from "@/components/DeviceListComponents.vue";
import axios from "axios";

export default {
  name: "RightSidebarComponents",
  components: {DeviceList, UserIcon, UserList},
  data() {
    return {
      user: {
        name: "",
      }
    }
  },
  computed: {
    token() {
      return this.getCookie('token');
    },
  },
  watch: {
    token: {
      immediate: true, // 立即触发
      handler: function (newToken, oldToken) {
        if (newToken !== oldToken) {
          this.getUser();
        }
      }
    }
  },
  methods: {
    getCookie(name) {
      const value = `; ${document.cookie}`;
      const parts = value.split(`; ${name}=`);
      if (parts.length === 2) {
        return parts.pop().split(";").shift();
      }
    },
    async getUser() {
      // 携带token请求
      const res = await axios.get("http://101.43.162.244:8080/user/username", {
        headers: {
          token: this.token,
        },
      });
      this.user.name = res.data.data;
    },
  },
}
</script>

<template>
  <div class="rightSidebarComponents">
    <div class="verticalLine"></div>
    <div class="user">
      <div class="userIcon">
        <UserIcon />
      </div>
      <div class="userName">
        {{ user.name }}
      </div>
    </div>
    <div class="userList">
      <UserList />
    </div>
    <div class="deviceList">
      <DeviceList />
    </div>
  </div>
</template>

<style scoped>
.rightSidebarComponents {
  /* 设置大小 */
  height: 100%;
  width: 100%;
}

.verticalLine {
  position: absolute;
  height: 80%; /* 调整线的高度 */
  width: 2px; /* 设置线的宽度 */
  left: 0; /* 调整线的水平位置 */
  top: 15%; /* 调整线的垂直位置 */
  /* 设置黑色半透明 */
  background-color: rgba(0, 0, 0, 0.1);
}

.user {
  /* 放到右上角 */
  position: absolute;
  top: 5%;
  right: 50%;
  transform: translate(50%, 0%);
  /* 设置大小 */
  height: 5%;
  width: 80%;
  /* 设置不重复 */
  background-repeat: no-repeat;
}
.userIcon {
  /* 放到中间 */
  position: absolute;
  top: 50%;
  left: 20%;
  transform: translate(-50%, -50%);
  /* 设置大小 */
  height: 80%;
  width: 10%;
}
.userName {
  /* 放到中间 */
  position: absolute;
  top: 45%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 设置字体 */
  font-size: 20px;
  font-weight: bold;
}

.userList {
  /* 放到右上角 */
  position: absolute;
  top: 15%;
  right: 50%;
  transform: translate(50%, 0%);
  /* 设置大小 */
  height: 40%;
  width: 80%;
}
.deviceList {
  /* 放到右下角 */
  position: absolute;
  top: 55%;
  right: 50%;
  transform: translate(50%, 0%);
  /* 设置大小 */
  height: 40%;
  width: 80%;
}
</style>