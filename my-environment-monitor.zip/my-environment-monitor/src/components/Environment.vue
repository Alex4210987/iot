<template>
  <div class="panelComponents">
    <div class="panelComponentsTitle">
      监测面板
    </div>
    <div class="panelRow">
      <!-- 第一行 -->
      <div class="temperaturePanel panelCell">
        <div class="panelLayer">
          <div class="temperatureIcon">
            <TemperatureIcon />
          </div>
          <div class="temperatureTitle">
            当前温度
          </div>
          <div class="temperatureValue">
            {{ temperature }}℃
          </div>
        </div>
      </div>
      <div class="humidityPanel panelCell">
        <div class="panelLayer">
          <div class="humidityIcon">
            <HumidityIcon />
          </div>
          <div class="humidityTitle">
            当前湿度
          </div>
          <div class="humidityValue">
            {{ humidity }}%
          </div>
        </div>
      </div>
      <div class="soilHumidityPanel panelCell">
        <div class="panelLayer">
          <div class="soilHumidityIcon">
            <SoilHumidityIcon />
          </div>
          <div class="soilHumidityTitle">
            当前土壤湿度
          </div>
          <div class="soilHumidityValue">
            {{ soilHumidity }}%
          </div>
        </div>
      </div>
      <div class="precipitationPanel panelCell">
        <div class="panelLayer">
          <div class="precipitationIcon">
            <PrecipitationIcon />
          </div>
          <div class="precipitationTitle">
            当前降雨量
          </div>
          <div class="precipitationValue">
            {{ precipitation }}mm
          </div>
        </div>
      </div>
    </div>
     <div class="controlPanel">
      <!-- 控制按钮 -->
      <button @click="increaseTemperature">增加温度</button>
      <button @click="decreaseTemperature">减少温度</button>
    </div>
  </div>
</template>

<style scoped>
.panelComponents {
  background-color: pink;
  padding: 10px;
  border: 1px solid #ccc;
}

.panelComponentsTitle {
  font-size: 1.5em;
  font-weight: bold;
  margin-bottom: 10px;
}

.panelRow {
  display: flex;
  flex-wrap: wrap;
}

.panelCell {
  flex: 1 0 50%; /* 每个单元格占据一半的宽度 */
  padding: 10px;
  box-sizing: border-box;
}

.panelLayer {
  background-color: #fff;
  border: 1px solid #ddd;
  padding: 10px;
  border-radius: 5px;
}

.controlPanel {
  margin-top: 20px;
}

.controlPanel button {
  margin: 0 5px;
  padding: 10px;
  font-size: 1em;
}

/* 可以根据需要调整各个面板的样式 */

</style>

<script>

import axios from "axios";
export default {
  name: "EnvironmentPanweaew",
  props: {
    nowData: {
      type: Object,
      default: () => ({
        temperature: 0,
        humidity: 0,
        soilHumidity: 0,
        precipitation: 0
      })
    }
  },
  data() {
    return {
      temperature: 0,
      humidity: 0,
      soilHumidity: 0,
      precipitation: 0,
      intervalId: null // 定时器ID
    }
  },
  watch: {
    nowData: {
      handler(newVal) {
        this.temperature = newVal.temperature;
        this.humidity = newVal.humidity;
        this.soilHumidity = newVal.soilHumidity;
        this.precipitation = newVal.precipitation;
      },
      deep: true
    }
  },
  methods: {
    increaseTemperature() {
      this.temperature++;
    },
    decreaseTemperature() {
      this.temperature--;
    },
    async fetchData() {
      try {
        const response = await axios.get('https://localhost:3070/data');
        const data = response.data;
        this.temperature = data.temperature;
        this.humidity = data.humidity;
        this.soilHumidity = data.soilHumidity;
        this.precipitation = data.precipitation;
      } catch (error) {
        console.log("Error fetching data:", error);
      }
    },
    startDataRefresh() {
      this.intervalId = setInterval(this.fetchData, 1000); // 每秒刷新一次
      this.fetchData(); // 初始加载数据
    },
    stopDataRefresh() {
      clearInterval(this.intervalId);
    }
  },
  mounted() {
    this.startDataRefresh();
  },
  beforeUnmout() {
    this.stopDataRefresh();
  }
};
</script>
