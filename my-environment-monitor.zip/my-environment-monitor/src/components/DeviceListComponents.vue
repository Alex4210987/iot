<template>
  <div class="deviceListComponents">
    <div class="deviceListTitle">
      在线设备列表
    </div>
    <div class="deviceListComponentsLayer">
      <div class="deviceList"
           v-for="device in devices"
           :key="device.name"
           @click="selectDevice(device.id)"
           :class="{'selectedDevice': user_mcu_id === device.id}">
        <div class="deviceIcon">
          <DeviceIcon />
        </div>
        <span class="deviceName">{{ device.name }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import DeviceIcon from "@/components/icon/DeviceIcon.vue";
import axios from "axios";
import {sharedState} from "@/sharedState";

export default {
  name: "DeviceListComponents",
  components: {
    DeviceIcon,
  },
  data() {
    return {
      devices: [
      ],
    };
  },
  computed: {
    token() {
      return this.getCookie('token');
    },
    user_mcu_id() {
      return sharedState.user_mcu_id;
    },
  },
  watch: {
    token: {
      immediate: true, // 立即触发
      handler: function (newToken, oldToken) {
        if (newToken !== oldToken) {
          this.getDevices();
        }
      }
    }
  },
  methods: {
    async getDevices() {
      if (this.token === undefined || this.token === '') {
        return;
      }
      // 携带token请求
      const res = await axios.get('http://101.43.162.244:8080/user/mcuList', {
        headers: {
          token: this.token,
        },
      });
      this.devices = res.data.data;
      console.log(this.devices);
    },
    selectDevice(id) {
      sharedState.user_mcu_id = id;
    },
    getCookie(name) {
      const value = `; ${document.cookie}`;
      const parts = value.split(`; ${name}=`);
      if (parts.length === 2) {
        return parts.pop().split(";").shift();
      }
    },
  },
};
</script>

<style scoped>
.deviceListComponents {
  /* 设置大小 */
  height: 100%;
  width: 100%;
}

.deviceListTitle {
  /* 设置左上角 */
  position: absolute;
  top: 0;
  left: 10%;
  /* 设置字体大小 */
  font-size: 20px;
  /* 设置字体颜色 */
  color: #000000;
  /* 设置字体粗细 */
  font-weight: bold;
}

.deviceListComponentsLayer {
  /* 设置背景为白色半透明 */
  background-color: rgba(255, 255, 255, 0.5);
  /* 设置圆角 */
  border-radius: 20px;
  /* 设置大小 */
  height: 80%;
  width: 90%;
  /* 移动到中间 */
  position: absolute;
  top: 55%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 设置滚动 */
  overflow-y: scroll;
}

.deviceList {
  display: flex;
  align-items: center;
  padding: 10px;
  /* 设置鼠标悬停时的样式 */
  cursor: pointer;
  /* 设置半透明 */
  opacity: 0.7;
  /* 设置过渡效果 */
  transition: all 0.3s;
}

.deviceList:hover {
  /* 设置半透明 */
  opacity: 1;
}



.deviceIcon {
  width: 24px;
  height: 24px;
  margin-right: 10px;
}

.deviceName {
  font-size: 18px;
}

.selectedDevice {
  opacity: 1;
}
</style>
