<script>
export default {
  name: "HomePageIcon"
}
</script>

<template>
  <div class="homePageIcon">
    </div>
</template>

<style scoped>
.homePageIcon {
  background-image: url('../../assets/homepage.png');
  /* 设置大小比例为原图的大小 */
  background-size: 50% 100%;
  /* 设置不重复 */
  background-repeat: no-repeat;
  /* 设置大小 */
  height: 100%;
  width: 100%;
}

</style>