<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <Environment msg="Welcome to Your Vue.js App"/>

  <div id="app" class="app">
    <div class="router-container">
    <router-view />
    <div class="Demo">
    <ParentDemo1/>
    <demoSix/>
  </div>
  </div>


  </div>
</template>

<script>

import Environment from './components/Environment.vue'
import ParentDemo1 from '@/demo/ParentComponent.vue'
import demoSix from '@/demo/MyDemos.vue'
export default {
  name: 'App',
  components: {
    Environment,
    ParentDemo1,
    demoSix
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.router-container {
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
  height: 100vh; /* 设置高度占满整个视口 */
}
</style>
