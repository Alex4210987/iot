// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import IndexPage from '../Page/indexPage.vue';
import AllDevicePage from '@/Page/AllDevicePage.vue'
import FaceReco from '@/Page/FaceReco.vue'
const routes = [
  {
    path: '/',
    name: 'IndexPage',
    component: IndexPage
  },
  {
    path:'/AllDevices',
    name:'Alldevices',
    component: AllDevicePage
  },
  {
    path:'/FaceRecognition',
    name:'FaceRecoPage',
    component:FaceReco
  }
  // 其他路由定义
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;

