package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"github.com/gin-gonic/gin"
	"github.com/huaweicloud/huaweicloud-sdk-go-v3/core/auth/basic"
	frs "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/frs/v2"
	"github.com/huaweicloud/huaweicloud-sdk-go-v3/services/frs/v2/model"
	region "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/frs/v2/region"
)

func main() {
	r := gin.Default()

	r.POST("/face/add", func(c *gin.Context) {
		file, err := c.FormFile("file")
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		fmt.Println(file.Filename)
		tempFilePath := filepath.Join(os.TempDir(), file.Filename)
		// 初始化华为云客户端
		if err := c.SaveUploadedFile(file, tempFilePath); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to save file"})
			return
		}
		fmt.Println(file.Size)
		fileContent, err := os.Open(tempFilePath)
		fmt.Println(fileContent.Name())
		auth := basic.NewCredentialsBuilder().
			WithAk("LB9WTRSVXC2D5FWGMKW2").
			WithSk("tkPt6z6q5Qz42ZdPjtxccZTvY8so5D6divdaLpqF").
			Build()

		client := frs.NewFrsClient(
			frs.FrsClientBuilder().
				WithRegion(region.ValueOf("cn-east-3")).
				WithCredential(auth).
				Build())

		// 调用华为云人脸识别API添加人脸
		request := &model.AddFacesByFileRequest{}
		response, err := client.AddFacesByFile(request)
		if err == nil {
			fmt.Printf("%+v\n", response)
		} else {
			fmt.Println(err)
		}

		fmt.Printf("Add faces response: %+v\n", response)
		c.JSON(http.StatusOK, gin.H{"message": "人脸添加成功"})
	})

	// 运行服务
	if err := r.Run(":3070"); err != nil {
		log.Fatalf("Failed to run server: %v", err)
	}
}
